#!/usr/bin/env bash

[[ `ps aux | grep "./gminer" | grep -v grep | wc -l` != 0 ]] &&
  echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
  exit 1

#try to release TIME_WAIT sockets
while true; do
  for con in `netstat -anp | grep TIME_WAIT | grep $MINER_API_PORT | awk '{print $5}'`; do
    killcx $con lo
  done
  netstat -anp | grep TIME_WAIT | grep $MINER_API_PORT &&
    continue ||
    break
done

export GPU_MAX_HEAP_SIZE=100
export GPU_MAX_ALLOC_PERCENT=100
export GPU_SINGLE_ALLOC_PERCENT=100

cd $MINER_DIR/$MINER_VER


API_DEFAULT_PROFILE_NAME="default"
API_REMOTE="https://cryptotech-crm-default-rtdb.europe-west1.firebasedatabase.app/"

# First try worker specific profile
API_PROFILE_NAME=`curl -s $API_REMOTE/worker/$RIG_ID/profile.json`

# Then farm default
[ $API_PROFILE_NAME == null ] && API_PROFILE_NAME=`curl -s $API_REMOTE/farm/$FARM_ID/default.json`

# Else check meta default
[ $API_PROFILE_NAME == null ] && API_PROFILE_NAME=`curl -s $API_REMOTE/meta/default.json`

# If all fails use a constant
[ $API_PROFILE_NAME == null ] && API_PROFILE_NAME="$API_DEFAULT_PROFILE_NAME"

# Trim off "s
API_PROFILE_NAME_SANITAIZED=$(echo $API_PROFILE_NAME | tr -d '"')

# Fetch configuration by it's name
API_CONFIGURATION=`curl -s $API_REMOTE/profile/$API_PROFILE_NAME_SANITAIZED.json`

# Extract needed property
configuration=$(echo $API_CONFIGURATION | jq -r '.miner')

./gminer $(< $MINER_NAME.conf) --logfile $MINER_LOG_BASENAME.log --api $MINER_API_PORT $(echo $configuration)
